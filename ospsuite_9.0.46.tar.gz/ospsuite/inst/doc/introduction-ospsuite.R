## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----loadSim------------------------------------------------------------------
library(ospsuite)

dataPath <- file.path(getwd(), "..", "tests", "data", fsep = .Platform$file.sep)
simFilePath <- file.path(dataPath, paste0("Aciclovir.pkml"), fsep = .Platform$file.sep)
print(simFilePath)

sim <- loadSimulation(simFilePath)
print(sim)

## ----getEntities--------------------------------------------------------------
#Get the container "Liver"
livContainer <- getContainer("Organism|Liver", sim)
print(livContainer)

#Get the molecule Aciclovir located in kindey intracellular space
moleculeInKid <- getMolecule("Organism|Kidney|Intracellular|Aciclovir", sim)
print(moleculeInKid)

#Get the parameter volume of the liver interstitial space. Note that the path used is relative to the liver container
livParam <- getParameter("Interstitial|Volume", livContainer)
print(livParam)

## ----getAllEntitiesMatching---------------------------------------------------
#Get the parameter `Volume` of the intracellular space of all organs, with exactly one path element before `Intracellular`
volumeParams <- getAllParametersMatching("Organism|*|Intracellular|Volume", sim)
length(volumeParams)
#The PBPK model has 15 organs with an "Intracellular" sub-

#Get the parameter `Volume` of the intracellular space of all organs, no matter how many sub-containers the organ has
volumeParams <- getAllParametersMatching("Organism|**|Intracellular|Volume", sim)
length(volumeParams)
#The list also includes parameters of organs like "Liver|Periportal", or the mucosal compartments of the intestine.

## ----getAllEntitiesMatching_multiplePaths-------------------------------------
#Get the molecule Aciclovir located in `Liver|Periportal|Intracellular` and `VenousBlood|Plasma`
molecules <- getAllMoleculesMatching(c("Organism|Liver|Periportal|Intracellular|Aciclovir", "Organism|VenousBlood|Plasma|Aciclovir"), sim)
print(molecules)

## ----containerProperties------------------------------------------------------
# Path of the container
livContainer$path

## ----moleculeProperties-------------------------------------------------------
#Initial value of the molecule
moleculeInKid$value

# Dimension of the molecule. See section "Unit conversion" for more information.
moleculeInKid$dimension

# Is the initial value defined by a formula?
moleculeInKid$isFormula

# Type of the formula. CONSTANT if the value is defined by a constant.
moleculeInKid$formula

## ----parameterProperties------------------------------------------------------
#Initial value of the parameter
livParam$value

# Dimension of the parameter. See section "Unit conversion" for more information.
livParam$dimension

# Base unit of the parameter. See section "Unit conversion" for more information.
livParam$unit

# Is the initial value defined by a formula?
livParam$isFormula

# Type of the formula. CONSTANT if the value is defined by a constant.
livParam$formula

## ----runSim-------------------------------------------------------------------
simulationResults <- runSimulation(simulation = sim)
print(simulationResults)

## ----getAllOutputSelections---------------------------------------------------
simulationResults$allQuantityPaths

## ----getOutputValues----------------------------------------------------------
# Get simulated results by path
resultsPath <- simulationResults$allQuantityPaths[[1]]
print(resultsPath)

resultsData <- getOutputValues(simulationResults, quantitiesOrPaths = resultsPath)

resultsTime <- resultsData$data$Time
resultsValues <- resultsData$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`

plot(resultsTime, resultsValues)

resultsValues <- resultsData$data[[3]]

plot(resultsTime, resultsValues)

## ----addOutputs---------------------------------------------------------------
# Clear the list of generated outputs
clearOutputs(sim)

# Add new outputs as objects
molecule <- getMolecule("Organism|Kidney|Intracellular|Aciclovir", sim)
observer <- getQuantity("Organism|Lumen|Aciclovir|Fraction dissolved", sim)

addOutputs(c(molecule, observer), simulation = sim)

# Add new ouputs as path strings
addOutputs(c("Organism|Lumen|Stomach|Aciclovir", "Organism|PeripheralVenousBlood|Aciclovir|Whole Blood (Peripheral Venous Blood)"), simulation = sim)

# Run simulation
simulationResults <- runSimulation(simulation = sim)

# Retrieve all generated outputs (e.g. omitting the quantitiesOrPaths property will return all available values)
resultsData <- getOutputValues(simulationResults)

# Note that "Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)" is not in the list of generated results any more
names(resultsData$data)

## ----runPopSim----------------------------------------------------------------
# Load simulation from pkml
sim <- loadSimulation(simFilePath)

# Load population information from csv
popFilePath <- file.path(dataPath, paste0("pop_10.csv"), fsep = .Platform$file.sep)
myPopulation <- loadPopulation(csvPopulationFile = popFilePath)
print(myPopulation)

# Run population simulation
populationResults <- runSimulation(simulation = sim, population = myPopulation)
print(populationResults)

## ----simulationRunOptions-----------------------------------------------------
# Create a SimulationRunOptions object
simRunOptions <- SimulationRunOptions$new()
print(simRunOptions)

# Change the maximal number of cores to use and show a progress bar during simulation
simRunOptions$numberOfCoresToUse <- 3
simRunOptions$showProgress <- TRUE

# Run population simulation with cutom options
populationResults <- runSimulation(simulation = sim, population = myPopulation, simulationRunOptions = simRunOptions)
print(populationResults)

## ----getSimulationOutputValues------------------------------------------------
# Get all simulated results
resultsData <- getOutputValues(simulationResults = populationResults)

resultsTime <- resultsData$data$Time
resultsValues <- resultsData$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`

plot(resultsTime, resultsValues)

# Accessing simulation values for specific individual by sub-setting `resultsData$data` with the respective individual id
individualData <- resultsData$data[resultsData$data$IndividualId == 2, ]
individualTime <- individualData$Time
individualValues <- individualData$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`
plot(individualTime, individualValues)

## ----changeDose---------------------------------------------------------------
# Get the parameter Dose
doseParamPath <- "Applications|IV 250mg 10min|Application_1|ProtocolSchemaItem|Dose"
doseParam <- getParameter(doseParamPath, sim)

# Get the value in mg - see section "Unit conversion" for additional information
toUnit(quantity = doseParam, values = doseParam$value, targetUnit = "mg")

# Simulate with default dose
results250mg <- runSimulation(simulation = sim)
values250mg <- getOutputValues(simulationResults = results250mg)

# Change the dose to 350mg. The values has to be converted to base unit, first
newValue <- toBaseUnit(quantity = doseParam, values = 350, unit = "mg")
setParameterValues(parameters = doseParam, values = newValue)

# Simulate with new dose
results350mg <- runSimulation(simulation = sim)
values350mg <- getOutputValues(simulationResults = results350mg)

# Plot the results of the 250mg simulation
plot(values250mg$data$Time, values250mg$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`, type = "l")

# Add the results of the 350mg simulation
points(values350mg$data$Time, values350mg$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`, type = "l", col = "red")
legend("topright", legend = c("250mg", "350mg"), col = c("black", "red"), lty = c(1,1))

## ----scaleParameter-----------------------------------------------------------
doseParamPath <- "Applications|IV 250mg 10min|Application_1|ProtocolSchemaItem|Dose"
doseParam <- getParameter(doseParamPath, sim)
print(doseParam)

# Double the dose
scaleParameterValues(doseParam, factor = 2)
print(doseParam)

# Half the dose
scaleParameterValues(doseParam, factor = 0.5)
print(doseParam)

## ----changeInitialValue-------------------------------------------------------
# Get objects representing the molecule Aciclovir in all containers
allAciclovirMolecules <- getAllMoleculesMatching("Organism|**|Aciclovir",sim)

#Set initial values to 10 µmol in all containers
setMoleculeInitialValues(allAciclovirMolecules, rep(10, length(allAciclovirMolecules)))

# Simulate
results350mg_newInitCond <- runSimulation(simulation = sim)
values350mg_newInitCond <- getOutputValues(simulationResults = results350mg_newInitCond)

# Plot the results of the 3350mg simulation
plot(values350mg$data$Time, values350mg$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`, type = "l")

# Add the results of the simulation with new initial conditions
points(values350mg_newInitCond$data$Time, values350mg_newInitCond$data$`Organism|PeripheralVenousBlood|Aciclovir|Plasma (Peripheral Venous Blood)`, type = "l", col = "red")

## ----$outputSchema------------------------------------------------------------
print(sim$outputSchema)

## ----$dimension---------------------------------------------------------------
print(livParam)
livParam$dimension


## ----$allUnits----------------------------------------------------------------
print(livParam)
livParam$allUnits


## ----unitConversion-----------------------------------------------------------
# Get the BMI parameter
bmiParam <- getParameter("Organism|BMI", sim)
print(bmiParam)

# Print the base and the default display units
bmiParam$unit
bmiParam$displayUnit

# Convert the value from the base into the default display unit
toDisplayUnit(quantity = bmiParam, values = bmiParam$value)

# Convert the value to the base unit, that can be used e.g. for setting new parameter value
toBaseUnit(quantity = bmiParam, values = 30, unit = "kg/m²")

liverVolume <- getParameter("Organism|Liver|Volume",sim)

print(liverVolume)
liverVolume$allUnits
# Convert from base volume unit to µl
toUnit(quantity = liverVolume, values = c(1,2,3,4), targetUnit = "ml")

