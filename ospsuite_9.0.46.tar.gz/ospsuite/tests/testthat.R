
library(testthat)
library(ospsuite)

test_check("ospsuite")
